<?php

require_once '../../config/config.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

// Initialize authentication
$auth = new Auth(getDBConnection());
$auth->requireAdmin();

// Verify CSRF token
if (!validateCSRFToken($_POST['csrf_token'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid security token']);
    exit;
}

try {
    $db = getDBConnection();
    $db->beginTransaction();

    $section = filter_input(INPUT_POST, 'section', FILTER_SANITIZE_STRING);
    if (!$section) {
        throw new Exception('Invalid settings section');
    }

    // Store old values for audit log
    $oldValues = [];
    $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings");
    while ($row = $stmt->fetch()) {
        $oldValues[$row['setting_key']] = $row['setting_value'];
    }

    // Process settings based on section
    switch ($section) {
        case 'general':
            saveGeneralSettings($db, $_POST);
            break;
        case 'email':
            saveEmailSettings($db, $_POST);
            break;
        case 'attendance':
            saveAttendanceSettings($db, $_POST);
            break;
        case 'notifications':
            saveNotificationSettings($db, $_POST);
            break;
        default:
            throw new Exception('Invalid settings section');
    }

    // Get new values for audit log
    $newValues = [];
    $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings");
    while ($row = $stmt->fetch()) {
        $newValues[$row['setting_key']] = $row['setting_value'];
    }

    // Log the changes
    $stmt = $db->prepare("
        INSERT INTO audit_logs (
            user_id, action, table_name, 
            record_id, old_values, new_values
        ) VALUES (?, 'update_settings', 'system_settings', 0, ?, ?)
    ");
    
    $stmt->execute([
        $_SESSION['user_id'],
        json_encode($oldValues),
        json_encode($newValues)
    ]);

    $db->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Settings updated successfully'
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function saveGeneralSettings($db, $data) {
    // Validate timezone
    if (!in_array($data['default_timezone'], DateTimeZone::listIdentifiers())) {
        throw new Exception('Invalid timezone');
    }

    // Validate date format
    $validDateFormats = ['Y-m-d', 'd/m/Y', 'm/d/Y'];
    if (!in_array($data['date_format'], $validDateFormats)) {
        throw new Exception('Invalid date format');
    }

    // Validate time format
    $validTimeFormats = ['H:i', 'h:i A'];
    if (!in_array($data['time_format'], $validTimeFormats)) {
        throw new Exception('Invalid time format');
    }

    updateSetting($db, 'company_name', $data['company_name']);
    updateSetting($db, 'default_timezone', $data['default_timezone']);
    updateSetting($db, 'date_format', $data['date_format']);
    updateSetting($db, 'time_format', $data['time_format']);
}

function saveEmailSettings($db, $data) {
    // Validate email
    if (!filter_var($data['from_email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    // Validate port
    if (!filter_var($data['smtp_port'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]])) {
        throw new Exception('Invalid SMTP port');
    }

    updateSetting($db, 'smtp_host', $data['smtp_host']);
    updateSetting($db, 'smtp_port', $data['smtp_port']);
    updateSetting($db, 'smtp_username', $data['smtp_username']);
    updateSetting($db, 'smtp_password', $data['smtp_password']);
    updateSetting($db, 'from_email', $data['from_email']);
    updateSetting($db, 'from_name', $data['from_name']);
}

function saveAttendanceSettings($db, $data) {
    // Validate numeric values
    if (!filter_var($data['location_accuracy'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 10, 'max_range' => 1000]])) {
        throw new Exception('Invalid location accuracy value');
    }

    if (!filter_var($data['default_grace_period'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 120]])) {
        throw new Exception('Invalid grace period value');
    }

    if (!filter_var($data['default_half_day_minutes'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 480]])) {
        throw new Exception('Invalid half day minutes value');
    }

    updateSetting($db, 'location_accuracy', $data['location_accuracy']);
    updateSetting($db, 'selfie_required', isset($data['selfie_required']) ? '1' : '0');
    updateSetting($db, 'default_grace_period', $data['default_grace_period']);
    updateSetting($db, 'default_half_day_minutes', $data['default_half_day_minutes']);
}

function saveNotificationSettings($db, $data) {
    updateSetting($db, 'notify_attendance', isset($data['notify_attendance']) ? '1' : '0');
    updateSetting($db, 'notify_leave_request', isset($data['notify_leave_request']) ? '1' : '0');
    updateSetting($db, 'notify_leave_approval', isset($data['notify_leave_approval']) ? '1' : '0');
    
    if (isset($data['notify_admins'])) {
        updateSetting($db, 'notify_admins', implode(',', $data['notify_admins']));
    }
}

function updateSetting($db, $key, $value) {
    $stmt = $db->prepare("
        INSERT INTO system_settings (setting_key, setting_value)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $stmt->execute([$key, $value]);
}