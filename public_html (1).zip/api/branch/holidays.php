<?php

require_once '../../config/config.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

// Initialize authentication
$auth = new Auth(getDBConnection());
$auth->requireAdmin();

// Verify CSRF token from header
$csrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!validateCSRFToken($csrfToken)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid security token']);
    exit;
}

try {
    $branchId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    
    if (!$branchId) {
        throw new Exception('Invalid branch ID');
    }

    $db = getDBConnection();
    
    // Get holidays for the branch
    $stmt = $db->prepare("
        SELECT 
            h.id,
            h.name,
            h.date,
            h.created_at,
            u.employee_id as created_by_employee_id,
            ep.full_name as created_by_name
        FROM holidays h
        JOIN users u ON h.created_by = u.id
        JOIN employee_profiles ep ON u.id = ep.user_id
        WHERE h.branch_id = ?
        ORDER BY h.date ASC
    ");
    
    $stmt->execute([$branchId]);
    $holidays = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'holidays' => $holidays
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}