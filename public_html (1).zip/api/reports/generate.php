<?php

require_once '../../config/config.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

// Initialize authentication
$auth = new Auth(getDBConnection());
$auth->requireAdmin();

try {
    $db = getDBConnection();

    // Get filter parameters
    $reportType = filter_input(INPUT_POST, 'report_type', FILTER_SANITIZE_STRING) ?? 'attendance';
    $dateRange = filter_input(INPUT_POST, 'date_range', FILTER_SANITIZE_STRING);
    $startDate = filter_input(INPUT_POST, 'start_date', FILTER_SANITIZE_STRING);
    $endDate = filter_input(INPUT_POST, 'end_date', FILTER_SANITIZE_STRING);
    $branchId = filter_input(INPUT_POST, 'branch_id', FILTER_VALIDATE_INT);
    $department = filter_input(INPUT_POST, 'department', FILTER_SANITIZE_STRING);
    $employee = filter_input(INPUT_POST, 'employee', FILTER_SANITIZE_STRING);

    // Calculate date range if not custom
    if ($dateRange !== 'custom') {
        list($startDate, $endDate) = calculateDateRange($dateRange);
    }

    // Generate report based on type
    switch ($reportType) {
        case 'attendance':
            $report = generateAttendanceReport($db, $startDate, $endDate, $branchId, $department, $employee);
            break;
        case 'leave':
            $report = generateLeaveReport($db, $startDate, $endDate, $branchId, $department, $employee);
            break;
        case 'performance':
            $report = generatePerformanceReport($db, $startDate, $endDate, $branchId, $department, $employee);
            break;
        default:
            throw new Exception('Invalid report type');
    }

    echo json_encode([
        'success' => true,
        'report' => $report
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function calculateDateRange($range) {
    $endDate = date('Y-m-d');
    
    switch ($range) {
        case 'current_month':
            $startDate = date('Y-m-01');
            break;
        case 'last_month':
            $startDate = date('Y-m-01', strtotime('-1 month'));
            $endDate = date('Y-m-t', strtotime('-1 month'));
            break;
        case 'last_3_months':
            $startDate = date('Y-m-d', strtotime('-3 months'));
            break;
        case 'last_6_months':
            $startDate = date('Y-m-d', strtotime('-6 months'));
            break;
        case 'current_year':
            $startDate = date('Y-01-01');
            break;
        default:
            throw new Exception('Invalid date range');
    }

    return [$startDate, $endDate];
}

function generateAttendanceReport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Build base query
    $query = "
        SELECT 
            a.date,
            a.status,
            a.check_in,
            a.check_out,
            ep.full_name,
            ep.department,
            b.name as branch_name,
            CASE 
                WHEN TIME(a.check_in) > ADDTIME(bs.shift_start_time, SEC_TO_TIME(bs.grace_period_minutes * 60))
                THEN 'Late'
                ELSE 'On Time'
            END as arrival_status
        FROM attendance a
        JOIN users u ON a.user_id = u.id
        JOIN employee_profiles ep ON u.id = ep.user_id
        JOIN branches b ON ep.branch_id = b.id
        JOIN branch_settings bs ON b.id = bs.branch_id
        WHERE a.date BETWEEN ? AND ?
    ";

    $params = [$startDate, $endDate];

    // Add filters
    if ($branchId) {
        $query .= " AND b.id = ?";
        $params[] = $branchId;
    }
    if ($department) {
        $query .= " AND ep.department = ?";
        $params[] = $department;
    }
    if ($employee) {
        $query .= " AND (ep.full_name LIKE ? OR u.employee_id LIKE ?)";
        $params[] = "%$employee%";
        $params[] = "%$employee%";
    }

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $records = $stmt->fetchAll();

    // Calculate summary
    $summary = [
        'total_records' => count($records),
        'present_count' => 0,
        'absent_count' => 0,
        'late_count' => 0,
        'on_time_count' => 0
    ];

    foreach ($records as $record) {
        if ($record['status'] === 'present') {
            $summary['present_count']++;
            if ($record['arrival_status'] === 'Late') {
                $summary['late_count']++;
            } else {
                $summary['on_time_count']++;
            }
        } else {
            $summary['absent_count']++;
        }
    }

    // Calculate percentages
    $total = $summary['total_records'] ?: 1; // Avoid division by zero
    $summary['present_percentage'] = round(($summary['present_count'] / $total) * 100, 2);
    $summary['absent_percentage'] = round(($summary['absent_count'] / $total) * 100, 2);
    $summary['late_percentage'] = round(($summary['late_count'] / $total) * 100, 2);

    // Generate chart data
    $chartData = generateAttendanceChartData($records);

    // Prepare detailed tables
    $tables = [
        'Daily Attendance' => prepareDailyAttendanceTable($records),
        'Department Summary' => generateDepartmentSummary($records)
    ];

    return [
        'summary' => $summary,
        'charts' => $chartData,
        'tables' => $tables
    ];
}

function generateAttendanceChartData($records) {
    // Group records by date
    $dateGroups = [];
    foreach ($records as $record) {
        $date = $record['date'];
        if (!isset($dateGroups[$date])) {
            $dateGroups[$date] = [
                'present' => 0,
                'absent' => 0,
                'late' => 0,
                'on_time' => 0
            ];
        }

        if ($record['status'] === 'present') {
            $dateGroups[$date]['present']++;
            if ($record['arrival_status'] === 'Late') {
                $dateGroups[$date]['late']++;
            } else {
                $dateGroups[$date]['on_time']++;
            }
        } else {
            $dateGroups[$date]['absent']++;
        }
    }

    // Sort by date
    ksort($dateGroups);

    // Prepare chart data
    return [
        'attendance' => [
            'labels' => array_keys($dateGroups),
            'present' => array_column($dateGroups, 'present'),
            'absent' => array_column($dateGroups, 'absent')
        ],
        'punctuality' => [
            'labels' => array_keys($dateGroups),
            'onTime' => array_column($dateGroups, 'on_time'),
            'late' => array_column($dateGroups, 'late')
        ]
    ];
}

function prepareDailyAttendanceTable($records) {
    // Sort records by date and name
    usort($records, function($a, $b) {
        $dateCompare = strcmp($b['date'], $a['date']);
        if ($dateCompare === 0) {
            return strcmp($a['full_name'], $b['full_name']);
        }
        return $dateCompare;
    });

    return array_map(function($record) {
        return [
            'date' => $record['date'],
            'employee_name' => $record['full_name'],
            'department' => $record['department'],
            'branch' => $record['branch_name'],
            'status' => $record['status'],
            'check_in' => $record['check_in'] ? date('h:i A', strtotime($record['check_in'])) : '-',
            'check_out' => $record['check_out'] ? date('h:i A', strtotime($record['check_out'])) : '-',
            'arrival_status' => $record['arrival_status']
        ];
    }, $records);
}

function generateDepartmentSummary($records) {
    $departments = [];
    foreach ($records as $record) {
        $dept = $record['department'];
        if (!isset($departments[$dept])) {
            $departments[$dept] = [
                'total' => 0,
                'present' => 0,
                'absent' => 0,
                'late' => 0
            ];
        }

        $departments[$dept]['total']++;
        if ($record['status'] === 'present') {
            $departments[$dept]['present']++;
            if ($record['arrival_status'] === 'Late') {
                $departments[$dept]['late']++;
            }
        } else {
            $departments[$dept]['absent']++;
        }
    }

    $summary = [];
    foreach ($departments as $dept => $stats) {
        $summary[] = [
            'department' => $dept,
            'total_employees' => $stats['total'],
            'present' => $stats['present'],
            'absent' => $stats['absent'],
            'late' => $stats['late'],
            'attendance_rate' => round(($stats['present'] / $stats['total']) * 100, 2) . '%'
        ];
    }

    return $summary;
}

function generateLeaveReport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Build base query
    $query = "
        SELECT 
            la.id,
            la.user_id,
            la.leave_type,
            la.start_date,
            la.end_date,
            la.status,
            la.reason,
            la.created_at,
            u.employee_id,
            ep.full_name,
            ep.department,
            b.name as branch_name,
            DATEDIFF(la.end_date, la.start_date) + 1 as duration_days
        FROM leave_applications la
        JOIN users u ON la.user_id = u.id
        JOIN employee_profiles ep ON u.id = ep.user_id
        JOIN branches b ON ep.branch_id = b.id
        WHERE (la.start_date BETWEEN ? AND ? OR la.end_date BETWEEN ? AND ?)
    ";

    $params = [$startDate, $endDate, $startDate, $endDate];

    // Add filters
    if ($branchId) {
        $query .= " AND b.id = ?";
        $params[] = $branchId;
    }
    if ($department) {
        $query .= " AND ep.department = ?";
        $params[] = $department;
    }
    if ($employee) {
        $query .= " AND (ep.full_name LIKE ? OR u.employee_id LIKE ?)";
        $params[] = "%$employee%";
        $params[] = "%$employee%";
    }

    $query .= " ORDER BY la.start_date DESC";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $records = $stmt->fetchAll();

    // Calculate summary
    $summary = [
        'total_leaves' => count($records),
        'emergency_leaves' => 0,
        'privilege_leaves' => 0,
        'approved_leaves' => 0,
        'rejected_leaves' => 0,
        'pending_leaves' => 0,
        'total_days' => 0
    ];

    foreach ($records as $record) {
        $summary['total_days'] += $record['duration_days'];
        
        if ($record['leave_type'] === 'emergency') {
            $summary['emergency_leaves']++;
        } else {
            $summary['privilege_leaves']++;
        }

        switch ($record['status']) {
            case 'approved':
                $summary['approved_leaves']++;
                break;
            case 'rejected':
                $summary['rejected_leaves']++;
                break;
            case 'pending':
                $summary['pending_leaves']++;
                break;
        }
    }

    // Calculate average duration
    $summary['average_duration'] = $summary['total_leaves'] ? 
        round($summary['total_days'] / $summary['total_leaves'], 1) : 0;

    // Generate chart data
    $chartData = [
        'leaveTypes' => [
            'labels' => ['Emergency Leave', 'Privilege Leave'],
            'values' => [$summary['emergency_leaves'], $summary['privilege_leaves']]
        ],
        'leaveTrend' => generateLeaveTrendData($records)
    ];

    // Prepare tables
    $tables = [
        'Leave Applications' => prepareLeaveTable($records),
        'Department Summary' => generateDepartmentLeaveSummary($records)
    ];

    return [
        'summary' => $summary,
        'charts' => $chartData,
        'tables' => $tables
    ];
}

function generateLeaveTrendData($records) {
    $monthlyData = [];
    
    // Group leaves by month
    foreach ($records as $record) {
        $month = date('Y-m', strtotime($record['start_date']));
        if (!isset($monthlyData[$month])) {
            $monthlyData[$month] = 0;
        }
        $monthlyData[$month] += $record['duration_days'];
    }

    // Sort by month
    ksort($monthlyData);

    return [
        'labels' => array_keys($monthlyData),
        'values' => array_values($monthlyData)
    ];
}

function prepareLeaveTable($records) {
    return array_map(function($record) {
        return [
            'employee_id' => $record['employee_id'],
            'employee_name' => $record['full_name'],
            'department' => $record['department'],
            'leave_type' => ucfirst($record['leave_type']),
            'start_date' => date('Y-m-d', strtotime($record['start_date'])),
            'end_date' => date('Y-m-d', strtotime($record['end_date'])),
            'duration' => $record['duration_days'] . ' days',
            'status' => ucfirst($record['status']),
            'applied_on' => date('Y-m-d', strtotime($record['created_at']))
        ];
    }, $records);
}

function generateDepartmentLeaveSummary($records) {
    $departments = [];
    
    foreach ($records as $record) {
        $dept = $record['department'];
        if (!isset($departments[$dept])) {
            $departments[$dept] = [
                'total_leaves' => 0,
                'emergency_leaves' => 0,
                'privilege_leaves' => 0,
                'total_days' => 0,
                'approved_leaves' => 0
            ];
        }

        $departments[$dept]['total_leaves']++;
        $departments[$dept]['total_days'] += $record['duration_days'];

        if ($record['leave_type'] === 'emergency') {
            $departments[$dept]['emergency_leaves']++;
        } else {
            $departments[$dept]['privilege_leaves']++;
        }

        if ($record['status'] === 'approved') {
            $departments[$dept]['approved_leaves']++;
        }
    }

    $summary = [];
    foreach ($departments as $dept => $stats) {
        $summary[] = [
            'department' => $dept,
            'total_leaves' => $stats['total_leaves'],
            'emergency_leaves' => $stats['emergency_leaves'],
            'privilege_leaves' => $stats['privilege_leaves'],
            'average_duration' => round($stats['total_days'] / $stats['total_leaves'], 1),
            'approval_rate' => round(($stats['approved_leaves'] / $stats['total_leaves']) * 100, 1) . '%'
        ];
    }

    return $summary;
}

function generatePerformanceReport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Get attendance and leave data for performance calculation
    $query = "
        SELECT 
            u.id as user_id,
            u.employee_id,
            ep.full_name,
            ep.department,
            ep.branch_id,
            b.name as branch_name,
            COUNT(DISTINCT a.date) as total_working_days,
            SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_days,
            SUM(CASE 
                WHEN a.status = 'present' AND 
                     TIME(a.check_in) > ADDTIME(bs.shift_start_time, SEC_TO_TIME(bs.grace_period_minutes * 60))
                THEN 1 
                ELSE 0 
            END) as late_days,
            COUNT(DISTINCT CASE WHEN la.status = 'approved' THEN la.id END) as approved_leaves,
            SUM(CASE 
                WHEN la.status = 'approved' 
                THEN DATEDIFF(la.end_date, la.start_date) + 1 
                ELSE 0 
            END) as total_leave_days
        FROM users u
        JOIN employee_profiles ep ON u.id = ep.user_id
        JOIN branches b ON ep.branch_id = b.id
        JOIN branch_settings bs ON b.id = bs.branch_id
        LEFT JOIN attendance a ON u.id = a.user_id 
            AND a.date BETWEEN ? AND ?
        LEFT JOIN leave_applications la ON u.id = la.user_id 
            AND la.start_date BETWEEN ? AND ?
        WHERE u.role = 'employee'
    ";

    $params = [$startDate, $endDate, $startDate, $endDate];

    // Add filters
    if ($branchId) {
        $query .= " AND b.id = ?";
        $params[] = $branchId;
    }
    if ($department) {
        $query .= " AND ep.department = ?";
        $params[] = $department;
    }
    if ($employee) {
        $query .= " AND (ep.full_name LIKE ? OR u.employee_id LIKE ?)";
        $params[] = "%$employee%";
        $params[] = "%$employee%";
    }

    $query .= " GROUP BY u.id";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $records = $stmt->fetchAll();

    // Calculate performance metrics
    $totalEmployees = count($records);
    $summary = [
        'total_employees' => $totalEmployees,
        'average_attendance' => 0,
        'average_punctuality' => 0,
        'high_performers' => 0,
        'needs_improvement' => 0
    ];

    $performanceData = [];
    foreach ($records as $record) {
        // Calculate various scores
        $attendanceScore = calculateAttendanceScore(
            $record['present_days'],
            $record['total_working_days'],
            $record['approved_leaves']
        );

        $punctualityScore = calculatePunctualityScore(
            $record['late_days'],
            $record['present_days']
        );

        $leaveManagementScore = calculateLeaveManagementScore(
            $record['total_leave_days'],
            $record['approved_leaves'],
            $startDate,
            $endDate
        );

        // Calculate overall rating
        $overallRating = ($attendanceScore * 0.4) + ($punctualityScore * 0.4) + ($leaveManagementScore * 0.2);

        // Update summary
        $summary['average_attendance'] += $attendanceScore;
        $summary['average_punctuality'] += $punctualityScore;

        if ($overallRating >= 80) {
            $summary['high_performers']++;
        } elseif ($overallRating < 60) {
            $summary['needs_improvement']++;
        }

        // Store individual performance data
        $performanceData[] = [
            'employee_id' => $record['employee_id'],
            'employee_name' => $record['full_name'],
            'department' => $record['department'],
            'branch' => $record['branch_name'],
            'attendance_score' => round($attendanceScore, 1),
            'punctuality_score' => round($punctualityScore, 1),
            'leave_management_score' => round($leaveManagementScore, 1),
            'overall_rating' => round($overallRating, 1)
        ];
    }

    // Finalize summary calculations
    if ($totalEmployees > 0) {
        $summary['average_attendance'] = round($summary['average_attendance'] / $totalEmployees, 1);
        $summary['average_punctuality'] = round($summary['average_punctuality'] / $totalEmployees, 1);
    }

    // Generate chart data
    $chartData = [
        'performance' => generatePerformanceChartData($performanceData),
        'trend' => generatePerformanceTrendData($db, $startDate, $endDate, $branchId, $department, $employee)
    ];

    // Prepare tables
    $tables = [
        'Employee Performance' => $performanceData,
        'Department Summary' => generateDepartmentPerformanceSummary($performanceData)
    ];

    return [
        'summary' => $summary,
        'charts' => $chartData,
        'tables' => $tables
    ];
}

function calculateAttendanceScore($presentDays, $totalDays, $approvedLeaves) {
    if ($totalDays == 0) return 0;
    $effectivePresence = $presentDays + $approvedLeaves;
    return min(100, ($effectivePresence / $totalDays) * 100);
}

function calculatePunctualityScore($lateDays, $presentDays) {
    if ($presentDays == 0) return 0;
    $onTimeDays = $presentDays - $lateDays;
    return ($onTimeDays / $presentDays) * 100;
}

function calculateLeaveManagementScore($totalLeaveDays, $approvedLeaves, $startDate, $endDate) {
    // Calculate maximum allowed leaves for the period
    $monthsDiff = ceil((strtotime($endDate) - strtotime($startDate)) / (30 * 24 * 60 * 60));
    $maxLeaves = $monthsDiff * (EMERGENCY_LEAVES_PER_MONTH + PRIVILEGE_LEAVES_PER_MONTH);
    
    if ($maxLeaves == 0) return 100;
    return min(100, (1 - ($totalLeaveDays / $maxLeaves)) * 100);
}

function generatePerformanceChartData($performanceData) {
    // Calculate averages for each metric
    $metrics = [
        'Attendance' => array_column($performanceData, 'attendance_score'),
        'Punctuality' => array_column($performanceData, 'punctuality_score'),
        'Leave Management' => array_column($performanceData, 'leave_management_score'),
        'Overall' => array_column($performanceData, 'overall_rating')
    ];

    $averages = array_map(function($scores) {
        return array_sum($scores) / count($scores);
    }, $metrics);

    return [
        'labels' => array_keys($metrics),
        'values' => array_values($averages)
    ];
}

function generatePerformanceTrendData($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Calculate performance for each month in the range
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $interval = new DateInterval('P1M');
    $period = new DatePeriod($start, $interval, $end);

    $trend = [];
    foreach ($period as $date) {
        $monthStart = $date->format('Y-m-01');
        $monthEnd = $date->format('Y-m-t');

        // Get monthly performance data
        $monthlyData = generatePerformanceReport(
            $db, $monthStart, $monthEnd, $branchId, $department, $employee
        );

        $trend[$date->format('Y-m')] = $monthlyData['summary']['average_attendance'];
    }

    return [
        'labels' => array_keys($trend),
        'values' => array_values($trend)
    ];
}

function generateDepartmentPerformanceSummary($performanceData) {
    $departments = [];
    
    // Group performance data by department
    foreach ($performanceData as $record) {
        $dept = $record['department'];
        if (!isset($departments[$dept])) {
            $departments[$dept] = [
                'department' => $dept,
                'total_employees' => 0,
                'attendance_score' => 0,
                'punctuality_score' => 0,
                'leave_score' => 0,
                'overall_rating' => 0,
                'high_performers' => 0,
                'needs_improvement' => 0
            ];
        }

        $departments[$dept]['total_employees']++;
        $departments[$dept]['attendance_score'] += $record['attendance_score'];
        $departments[$dept]['punctuality_score'] += $record['punctuality_score'];
        $departments[$dept]['leave_score'] += $record['leave_management_score'];
        $departments[$dept]['overall_rating'] += $record['overall_rating'];

        if ($record['overall_rating'] >= 80) {
            $departments[$dept]['high_performers']++;
        } elseif ($record['overall_rating'] < 60) {
            $departments[$dept]['needs_improvement']++;
        }
    }

    // Calculate averages and format data
    $summary = [];
    foreach ($departments as $dept => $stats) {
        $totalEmployees = $stats['total_employees'];
        $summary[] = [
            'department' => $dept,
            'total_employees' => $totalEmployees,
            'average_attendance' => round($stats['attendance_score'] / $totalEmployees, 1),
            'average_punctuality' => round($stats['punctuality_score'] / $totalEmployees, 1),
            'average_leave_score' => round($stats['leave_score'] / $totalEmployees, 1),
            'overall_rating' => round($stats['overall_rating'] / $totalEmployees, 1),
            'high_performers' => $stats['high_performers'],
            'needs_improvement' => $stats['needs_improvement'],
            'performance_ratio' => round(($stats['high_performers'] / $totalEmployees) * 100, 1) . '%'
        ];
    }

    return $summary;
}

function generateLeaveExport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Get leave data
    $leaveReport = generateLeaveReport($db, $startDate, $endDate, $branchId, $department, $employee);

    return [
        'Leave Details' => $leaveReport['tables']['Leave Applications'],
        'Department Summary' => $leaveReport['tables']['Department Summary']
    ];
}

function generatePerformanceExport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Get performance data
    $performanceReport = generatePerformanceReport($db, $startDate, $endDate, $branchId, $department, $employee);

    return [
        'Employee Performance' => $performanceReport['tables']['Employee Performance'],
        'Department Summary' => $performanceReport['tables']['Department Summary']
    ];
}

function formatPerformanceRating($rating) {
    if ($rating >= 90) return 'Excellent';
    if ($rating >= 80) return 'Very Good';
    if ($rating >= 70) return 'Good';
    if ($rating >= 60) return 'Satisfactory';
    return 'Needs Improvement';
}