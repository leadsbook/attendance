<?php

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'u664462742_Sugriva');
define('DB_PASS', '~^/Z+]9Oz');
define('DB_NAME', 'u664462742_Monkey');

// Application settings
define('APP_NAME', 'OneStaff');
define('APP_URL', 'https://onestaff.in');
define('TIMEZONE', 'Asia/Kolkata');

// Security settings
define('SESSION_LIFETIME', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 minutes
define('HASH_ALGO', PASSWORD_BCRYPT);
define('HASH_COST', 12); // Higher number = more secure but slower
define('SESSION_NAME', 'ONESTAFF_SESSION');
define('CSRF_TOKEN_NAME', 'onestaff_csrf_token');
define('COOKIE_SECURE', true);
define('COOKIE_HTTPONLY', true);
define('COOKIE_SAMESITE', 'Strict');

// File upload settings
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png']);

// Location settings
define('LOCATION_ACCURACY', 100); // Maximum allowed distance in meters

// Leave settings
define('EMERGENCY_LEAVES_PER_MONTH', 1);
define('PRIVILEGE_LEAVES_PER_MONTH', 2);

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__DIR__) . '/logs/error.log');

// Initialize database connection
function getDBConnection() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        error_log("Database connection failed: " . $e->getMessage());
        die("Database connection failed. Please try again later.");
    }
}

// Initialize session with enhanced security
function initSession() {
    // Set secure session parameters
    ini_set('session.cookie_httponly', COOKIE_HTTPONLY);
    ini_set('session.cookie_secure', COOKIE_SECURE);
    ini_set('session.use_strict_mode', true);
    ini_set('session.cookie_samesite', COOKIE_SAMESITE);
    
    // Custom session name
    session_name(SESSION_NAME);
    
    session_start();
    
    // Regenerate session ID periodically
    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } else if (time() - $_SESSION['created'] > 1800) {
        // Regenerate session ID every 30 minutes
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
    
    // Check session lifetime
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
        session_unset();
        session_destroy();
        header("Location: " . APP_URL . "/login.php");
        exit();
    }
    $_SESSION['last_activity'] = time();
}

// Generate CSRF token
function generateCSRFToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

// Validate CSRF token
function validateCSRFToken($token) {
    if (!isset($_SESSION[CSRF_TOKEN_NAME]) || empty($token) || $token !== $_SESSION[CSRF_TOKEN_NAME]) {
        error_log("CSRF token validation failed");
        return false;
    }
    return true;
}

// Hash password
function hashPassword($password) {
    return password_hash($password, HASH_ALGO, ['cost' => HASH_COST]);
}

// Validate password complexity
function isPasswordStrong($password) {
    // At least 8 characters long
    // Contains at least one uppercase letter
    // Contains at least one lowercase letter
    // Contains at least one number
    // Contains at least one special character
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}