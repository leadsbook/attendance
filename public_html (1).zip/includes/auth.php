<?php


class Auth {
    private $db;
    private $loginAttempts = [];

    public function __construct($db) {
        $this->db = $db;
    }

    /**
     * Authenticate user login
     */
    public function login($username, $password) {
        if ($this->isLockedOut($username)) {
            return ['success' => false, 'message' => 'Account is temporarily locked. Please try again later.'];
        }

        try {
            $stmt = $this->db->prepare("
                SELECT u.id, u.employee_id, u.password, u.role, ep.full_name, ep.branch_id 
                FROM users u 
                LEFT JOIN employee_profiles ep ON u.id = ep.user_id 
                WHERE u.username = ?
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $this->resetLoginAttempts($username);
                $this->createSession($user);
                return ['success' => true, 'user' => $user];
            }

            $this->incrementLoginAttempts($username);
            return ['success' => false, 'message' => 'Invalid username or password'];
        } catch (PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Login failed. Please try again.'];
        }
    }

    /**
     * Create user session
     */
    private function createSession($user) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['employee_id'] = $user['employee_id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['branch_id'] = $user['branch_id'];
        $_SESSION['last_activity'] = time();
        
        // Log login activity
        $this->logActivity($user['id'], 'login');
    }

    /**
     * Logout user
     */
    public function logout() {
        if (isset($_SESSION['user_id'])) {
            $this->logActivity($_SESSION['user_id'], 'logout');
        }
        
        session_unset();
        session_destroy();
        setcookie(session_name(), '', time() - 3600, '/');
    }

    /**
     * Check if user is logged in
     */
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && 
               isset($_SESSION['last_activity']) && 
               (time() - $_SESSION['last_activity'] < SESSION_LIFETIME);
    }

    /**
     * Check if user has admin role
     */
    public function isAdmin() {
        return $this->isLoggedIn() && $_SESSION['role'] === 'admin';
    }

    /**
     * Require authentication for protected pages
     */
    public function requireAuth() {
        if (!$this->isLoggedIn()) {
            header('Location: ' . APP_URL . '/login.php');
            exit();
        }
        $_SESSION['last_activity'] = time();
    }

    /**
     * Require admin role for protected pages
     */
    public function requireAdmin() {
        $this->requireAuth();
        if (!$this->isAdmin()) {
            header('Location: ' . APP_URL . '/unauthorized.php');
            exit();
        }
    }

    /**
     * Handle login attempts and lockouts
     */
    private function isLockedOut($username) {
        if (!isset($this->loginAttempts[$username])) {
            return false;
        }

        $attempts = $this->loginAttempts[$username];
        if ($attempts['count'] >= MAX_LOGIN_ATTEMPTS && 
            (time() - $attempts['timestamp'] < LOCKOUT_TIME)) {
            return true;
        }

        if (time() - $attempts['timestamp'] >= LOCKOUT_TIME) {
            $this->resetLoginAttempts($username);
        }

        return false;
    }

    private function incrementLoginAttempts($username) {
        if (!isset($this->loginAttempts[$username])) {
            $this->loginAttempts[$username] = ['count' => 0, 'timestamp' => time()];
        }
        $this->loginAttempts[$username]['count']++;
        $this->loginAttempts[$username]['timestamp'] = time();
    }

    private function resetLoginAttempts($username) {
        unset($this->loginAttempts[$username]);
    }

    /**
     * Log authentication activity
     */
    private function logActivity($userId, $action) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO audit_logs (user_id, action, table_name, record_id) 
                VALUES (?, ?, 'users', ?)
            ");
            $stmt->execute([$userId, $action, $userId]);
        } catch (PDOException $e) {
            error_log("Failed to log activity: " . $e->getMessage());
        }
    }
}