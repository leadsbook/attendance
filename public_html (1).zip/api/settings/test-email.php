<?php

require_once '../../config/config.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

// Initialize authentication
$auth = new Auth(getDBConnection());
$auth->requireAdmin();

// Verify CSRF token
if (!validateCSRFToken($_POST['csrf_token'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid security token']);
    exit;
}

try {
    // Validate email settings
    $host = filter_input(INPUT_POST, 'smtp_host', FILTER_SANITIZE_STRING);
    $port = filter_input(INPUT_POST, 'smtp_port', FILTER_VALIDATE_INT);
    $username = filter_input(INPUT_POST, 'smtp_username', FILTER_SANITIZE_STRING);
    $password = $_POST['smtp_password'] ?? '';
    $fromEmail = filter_input(INPUT_POST, 'from_email', FILTER_VALIDATE_EMAIL);
    $fromName = filter_input(INPUT_POST, 'from_name', FILTER_SANITIZE_STRING);

    if (!$host || !$port || !$username || !$password || !$fromEmail || !$fromName) {
        throw new Exception('All email settings are required');
    }

    // Initialize PHPMailer
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->SMTPAuth = true;
        $mail->Username = $username;
        $mail->Password = $password;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = $port;

        // Recipients
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($fromEmail); // Send test email to admin

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Test Email from ' . APP_NAME;
        $mail->Body = '
            <h1>Test Email</h1>
            <p>This is a test email from your ' . APP_NAME . ' installation.</p>
            <p>If you received this email, your email settings are configured correctly.</p>
            <p>Configuration used:</p>
            <ul>
                <li>SMTP Host: ' . htmlspecialchars($host) . '</li>
                <li>SMTP Port: ' . htmlspecialchars($port) . '</li>
                <li>From Email: ' . htmlspecialchars($fromEmail) . '</li>
                <li>From Name: ' . htmlspecialchars($fromName) . '</li>
            </ul>
            <p>Time sent: ' . date('Y-m-d H:i:s') . '</p>
        ';

        $mail->send();

        echo json_encode([
            'success' => true,
            'message' => 'Test email sent successfully'
        ]);

    } catch (PHPMailer\PHPMailer\Exception $e) {
        throw new Exception('Email error: ' . $mail->ErrorInfo);
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}