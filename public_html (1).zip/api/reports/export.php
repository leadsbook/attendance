<?php

require_once '../../config/config.php';
require_once '../../includes/auth.php';

// Initialize authentication
$auth = new Auth(getDBConnection());
$auth->requireAdmin();

try {
    $db = getDBConnection();

    // Get filter parameters
    $reportType = filter_input(INPUT_POST, 'report_type', FILTER_SANITIZE_STRING) ?? 'attendance';
    $dateRange = filter_input(INPUT_POST, 'date_range', FILTER_SANITIZE_STRING);
    $startDate = filter_input(INPUT_POST, 'start_date', FILTER_SANITIZE_STRING);
    $endDate = filter_input(INPUT_POST, 'end_date', FILTER_SANITIZE_STRING);
    $branchId = filter_input(INPUT_POST, 'branch_id', FILTER_VALIDATE_INT);
    $department = filter_input(INPUT_POST, 'department', FILTER_SANITIZE_STRING);
    $employee = filter_input(INPUT_POST, 'employee', FILTER_SANITIZE_STRING);

    // Calculate date range if not custom
    if ($dateRange !== 'custom') {
        list($startDate, $endDate) = calculateDateRange($dateRange);
    }

    // Generate report based on type
    switch ($reportType) {
        case 'attendance':
            $data = generateAttendanceExport($db, $startDate, $endDate, $branchId, $department, $employee);
            $filename = 'attendance_report';
            break;
        case 'leave':
            $data = generateLeaveExport($db, $startDate, $endDate, $branchId, $department, $employee);
            $filename = 'leave_report';
            break;
        case 'performance':
            $data = generatePerformanceExport($db, $startDate, $endDate, $branchId, $department, $employee);
            $filename = 'performance_report';
            break;
        default:
            throw new Exception('Invalid report type');
    }

    // Set headers for Excel download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '_' . date('Y-m-d') . '.xlsx"');
    header('Cache-Control: max-age=0');

    $spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Add report title
    $sheet->setCellValue('A1', strtoupper($reportType) . ' REPORT');
    $sheet->mergeCells('A1:H1');
    $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle('A1')->getAlignment()->setHorizontal('center');

    // Add date range
    $sheet->setCellValue('A2', 'Period: ' . date('M d, Y', strtotime($startDate)) . ' - ' . date('M d, Y', strtotime($endDate)));
    $sheet->mergeCells('A2:H2');
    $sheet->getStyle('A2')->getAlignment()->setHorizontal('center');

    // Add filters used
    $row = 4;
    if ($branchId) {
        $branch = $db->query("SELECT name FROM branches WHERE id = " . $branchId)->fetchColumn();
        $sheet->setCellValue('A' . $row, 'Branch: ' . $branch);
        $row++;
    }
    if ($department) {
        $sheet->setCellValue('A' . $row, 'Department: ' . $department);
        $row++;
    }
    if ($employee) {
        $sheet->setCellValue('A' . $row, 'Employee: ' . $employee);
        $row++;
    }

    $row += 1; // Add space before data

    // Add data
    foreach ($data as $sheetName => $sheetData) {
        if ($sheetName !== $spreadsheet->getActiveSheet()->getTitle()) {
            $sheet = $spreadsheet->createSheet();
            $sheet->setTitle($sheetName);
        }

        // Add headers
        $col = 'A';
        foreach (array_keys($sheetData[0]) as $header) {
            $sheet->setCellValue($col . $row, ucwords(str_replace('_', ' ', $header)));
            $sheet->getColumnDimension($col)->setAutoSize(true);
            $col++;
        }
        $sheet->getStyle('A' . $row . ':' . --$col . $row)->getFont()->setBold(true);
        $row++;

        // Add data
        foreach ($sheetData as $dataRow) {
            $col = 'A';
            foreach ($dataRow as $value) {
                $sheet->setCellValue($col . $row, $value);
                $col++;
            }
            $row++;
        }

        // Style the data
        $lastRow = $row - 1;
        $lastCol = --$col;
        
        $styleArray = [
            'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                ],
            ],
        ];
        
        $sheet->getStyle('A' . ($row - count($sheetData)) . ':' . $lastCol . $lastRow)
              ->applyFromArray($styleArray);

        $row += 2; // Add space before next section
    }

    // Auto-filter
    $sheet->setAutoFilter('A4:' . $lastCol . $lastRow);

    // Create Excel file
    $writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;

} catch (Exception $e) {
    // Log error
    error_log("Export error: " . $e->getMessage());
    
    // Return error response
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to generate export: ' . $e->getMessage()
    ]);
}

function generateAttendanceExport($db, $startDate, $endDate, $branchId, $department, $employee) {
    $query = "
        SELECT 
            a.date,
            u.employee_id,
            ep.full_name,
            ep.department,
            b.name as branch_name,
            a.status,
            a.check_in,
            a.check_out,
            CASE 
                WHEN TIME(a.check_in) > ADDTIME(bs.shift_start_time, SEC_TO_TIME(bs.grace_period_minutes * 60))
                THEN 'Late'
                ELSE 'On Time'
            END as arrival_status,
            TIMEDIFF(a.check_out, a.check_in) as hours_worked
        FROM attendance a
        JOIN users u ON a.user_id = u.id
        JOIN employee_profiles ep ON u.id = ep.user_id
        JOIN branches b ON ep.branch_id = b.id
        JOIN branch_settings bs ON b.id = bs.branch_id
        WHERE a.date BETWEEN ? AND ?
    ";

    $params = [$startDate, $endDate];

    if ($branchId) {
        $query .= " AND b.id = ?";
        $params[] = $branchId;
    }
    if ($department) {
        $query .= " AND ep.department = ?";
        $params[] = $department;
    }
    if ($employee) {
        $query .= " AND (ep.full_name LIKE ? OR u.employee_id LIKE ?)";
        $params[] = "%$employee%";
        $params[] = "%$employee%";
    }

    $query .= " ORDER BY a.date DESC, ep.full_name";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $records = $stmt->fetchAll();

    // Format data for Excel
    $detailedData = array_map(function($record) {
        return [
            'date' => date('Y-m-d', strtotime($record['date'])),
            'employee_id' => $record['employee_id'],
            'employee_name' => $record['full_name'],
            'department' => $record['department'],
            'branch' => $record['branch_name'],
            'status' => ucfirst($record['status']),
            'check_in' => $record['check_in'] ? date('h:i A', strtotime($record['check_in'])) : '-',
            'check_out' => $record['check_out'] ? date('h:i A', strtotime($record['check_out'])) : '-',
            'arrival_status' => $record['arrival_status'],
            'hours_worked' => $record['hours_worked'] ?? '-'
        ];
    }, $records);

    // Generate summary data
    $summaryData = generateAttendanceSummary($records);

    return [
        'Detailed Report' => $detailedData,
        'Summary' => $summaryData
    ];
}

function generateAttendanceSummary($records) {
    $summary = [];
    $departments = [];

    foreach ($records as $record) {
        $dept = $record['department'];
        if (!isset($departments[$dept])) {
            $departments[$dept] = [
                'department' => $dept,
                'total_employees' => 0,
                'present_count' => 0,
                'absent_count' => 0,
                'late_count' => 0,
                'total_hours' => 0
            ];
        }

        $departments[$dept]['total_employees']++;

        if ($record['status'] === 'present') {
            $departments[$dept]['present_count']++;
            if ($record['arrival_status'] === 'Late') {
                $departments[$dept]['late_count']++;
            }
            if ($record['hours_worked']) {
                $departments[$dept]['total_hours'] += strtotime($record['hours_worked']) - strtotime('00:00:00');
            }
        } else {
            $departments[$dept]['absent_count']++;
        }
    }

    foreach ($departments as $dept) {
        $total = $dept['total_employees'] ?: 1; // Avoid division by zero
        $summary[] = [
            'department' => $dept['department'],
            'total_employees' => $dept['total_employees'],
            'present_count' => $dept['present_count'],
            'absent_count' => $dept['absent_count'],
            'late_count' => $dept['late_count'],
            'attendance_rate' => round(($dept['present_count'] / $total) * 100, 2) . '%',
            'punctuality_rate' => round(100 - (($dept['late_count'] / $total) * 100), 2) . '%',
            'avg_hours_per_day' => $dept['present_count'] ? 
                round($dept['total_hours'] / $dept['present_count'] / 3600, 2) : 0
        ];
    }

    return $summary;
}

function generateLeaveExport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Implementation for leave export
    // Similar structure to attendance export but with leave-specific data
    // To be implemented based on leave management requirements
}

function generatePerformanceExport($db, $startDate, $endDate, $branchId, $department, $employee) {
    // Implementation for performance export
    // Similar structure to attendance export but with performance metrics
    // To be implemented based on performance tracking requirements
}